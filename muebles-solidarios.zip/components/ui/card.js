
export const Card = ({ children, ...props }) => <div style={{border: '1px solid #ddd', borderRadius: '8px'}} {...props}>{children}</div>;
export const CardContent = ({ children, ...props }) => <div style={{padding: '16px'}} {...props}>{children}</div>;
