
export const Tabs = ({ children }) => <div>{children}</div>;
export const TabsList = ({ children }) => <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>{children}</div>;
export const TabsTrigger = ({ children, ...props }) => <button {...props}>{children}</button>;
export const TabsContent = ({ children }) => <div>{children}</div>;
